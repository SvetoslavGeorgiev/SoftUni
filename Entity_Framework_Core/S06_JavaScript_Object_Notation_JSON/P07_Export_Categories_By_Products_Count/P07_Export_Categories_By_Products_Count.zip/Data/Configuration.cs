﻿namespace ProductShop.Data
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    public static class Configuration
    {

        public const string ConnectionString =
            @"Server=.\SQLEXPRESS;Database=ProductShop;Integrated Security=True;";

    }
}
