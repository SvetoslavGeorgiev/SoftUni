﻿namespace MusicHub.Data
{
   public static class Configuration
    {
        public static string ConnectionString =
            "Server=SGEORGIEV\\SQLEXPRESS;Database=MusicHub;Integrated Security=True;";
    }
}
