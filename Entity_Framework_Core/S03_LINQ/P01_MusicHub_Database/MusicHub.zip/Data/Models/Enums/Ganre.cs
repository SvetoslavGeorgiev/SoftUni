﻿namespace MusicHub.Data.Models.Enums
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    public enum Genre
    {
        Blues = 0,
        Rap = 10,
        PopMusic = 20,
        Rock = 30,
        Jazz = 40
    }
}
