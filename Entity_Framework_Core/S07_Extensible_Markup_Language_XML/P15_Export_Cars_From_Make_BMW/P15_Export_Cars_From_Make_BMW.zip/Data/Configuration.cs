﻿namespace CarDealer.Data
{
    

    public class Configuration
    {

        public const string ConnectionString =
            @"Server=.\SQLEXPRESS;Database=CarDealer;Trusted_Connection=True;";
    }
}
