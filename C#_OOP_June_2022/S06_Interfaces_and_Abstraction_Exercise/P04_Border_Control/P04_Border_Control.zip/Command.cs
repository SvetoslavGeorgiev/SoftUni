﻿namespace BorderControl
{
    using System;
    using System.Collections.Generic;
    using System.Text;
    public class Command
    {
        public string[] Arguments { get; set; }


    }
}
