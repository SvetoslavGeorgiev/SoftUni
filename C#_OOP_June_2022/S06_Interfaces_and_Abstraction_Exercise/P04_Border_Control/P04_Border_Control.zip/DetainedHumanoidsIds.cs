﻿namespace BorderControl
{
    using System;
    using System.Collections.Generic;
    using System.Text;
    public class DetainedHumanoidsIds
    {

        public List<string> IDsOfTheDetained { get; set; }

    }
}
