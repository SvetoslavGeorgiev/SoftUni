﻿namespace CollectionHierarchy.Contracts
{
    internal interface IRemove
    {
        string Remove();
    }
}
