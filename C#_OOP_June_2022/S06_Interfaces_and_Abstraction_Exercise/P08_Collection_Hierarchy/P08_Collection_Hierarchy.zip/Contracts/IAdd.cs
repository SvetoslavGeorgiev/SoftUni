﻿namespace CollectionHierarchy.Contracts
{
    internal interface IAdd
    {

        int Add(string element);

    }
}
