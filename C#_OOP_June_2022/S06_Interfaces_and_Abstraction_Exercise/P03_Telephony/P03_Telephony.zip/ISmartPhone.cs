﻿namespace Telephony
{
    public interface ISmartPhone
    {
        string Browse(string email);
    }
}
