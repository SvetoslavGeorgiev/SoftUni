﻿namespace Telephony
{
    public interface ISmartPhone : IPhone
    {
        string Browse(string email);
    }
}
