﻿namespace Telephony
{
    public interface IPhone
    {
        string Caling(string number);

    }
}
