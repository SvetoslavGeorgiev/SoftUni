﻿namespace ExplicitInterfaces.Contacts
{
    public interface IAge
    {
        int Age { get; }
    }
}
