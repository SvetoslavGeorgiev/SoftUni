﻿namespace ExplicitInterfaces.Contacts
{
    public interface ICountry
    {
        string Country { get; }
    }
}
