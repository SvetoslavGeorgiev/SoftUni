﻿namespace ExplicitInterfaces.Contacts
{
    public interface IName
    {
        string Name { get; }
    }
}
