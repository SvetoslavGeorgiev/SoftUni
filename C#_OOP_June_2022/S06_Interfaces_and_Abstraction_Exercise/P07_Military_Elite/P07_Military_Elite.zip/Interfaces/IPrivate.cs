﻿namespace MilitaryElite.Interfaces
{
    using System;
    using System.Collections.Generic;
    using System.Text;
    using Models;

    public interface IPrivate
    {
        public decimal Salary { get; }

    }
}
