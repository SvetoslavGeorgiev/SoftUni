﻿namespace MilitaryElite.Engine
{
    using System;
    using System.Collections.Generic;
    using System.Text;
    using Models;

    public class Privates
    {
        
        public List<Private> PrivatesList { get; set; } = new List<Private>();
        
    }
}
