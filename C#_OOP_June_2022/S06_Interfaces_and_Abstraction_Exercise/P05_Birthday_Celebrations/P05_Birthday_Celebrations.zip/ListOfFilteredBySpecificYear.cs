﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BirthdayCelebrations
{
    public class ListOfFilteredBySpecificYear
    {
        public List<string> specifiedListOfBirthdates { get; set; }
    }
}
