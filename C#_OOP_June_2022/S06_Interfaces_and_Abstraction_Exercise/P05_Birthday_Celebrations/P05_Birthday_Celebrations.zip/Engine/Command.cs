﻿namespace BirthdayCelebrations.Engine
{
    using System;
    using System.Collections.Generic;
    using System.Text;
    public class Command
    {

        public string Name { get; set; }
        public string[] Arguments { get; set; }


    }
}
