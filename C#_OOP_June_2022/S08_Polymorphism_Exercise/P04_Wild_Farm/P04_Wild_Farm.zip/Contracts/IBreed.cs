﻿namespace WildFarm.Contracts
{
    public interface IBreed
    {
        string Breed { get; }
    }
}
