﻿namespace Raiding.Contracts
{
    public interface ICastAbility
    {
        string CastAbility();
    }
}
