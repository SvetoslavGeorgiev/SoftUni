﻿namespace Raiding.Contracts
{
    public interface IPower
    {
        int Power { get; }
    }
}
