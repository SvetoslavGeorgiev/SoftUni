﻿namespace Vehicles.Contracts
{
    using System;
    using System.Collections.Generic;
    using System.Text;
    public interface IDrive
    {

        string Drive(double distance);

    }
}
