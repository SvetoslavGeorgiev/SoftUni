﻿namespace Vehicles.Contracts
{
    public interface IDriveEmpty
    {
        string DriveEmpry(double distance);
    }
}
