﻿namespace Vehicles.Contracts
{
    public interface IDrive
    {

        string Drive(double distance);

    }
}
