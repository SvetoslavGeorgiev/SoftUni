﻿namespace Vehicles.Contracts
{
    public interface IRefill
    {
        void Refill(double fuel);
    }
}
