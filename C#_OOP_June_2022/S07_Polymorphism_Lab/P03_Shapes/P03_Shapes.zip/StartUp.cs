﻿namespace Shapes
{
    using System;
    public class StartUp
    {
        static void Main()
        {


        }
    }
}
