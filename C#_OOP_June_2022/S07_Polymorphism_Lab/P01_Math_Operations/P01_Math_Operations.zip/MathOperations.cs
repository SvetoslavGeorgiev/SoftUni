﻿namespace Operations
{
    using System;
    using System.Collections.Generic;
    using System.Text;
    public class MathOperations
    {


        public int Add(int number1, int number2)
        {
            return number1 + number2;
        }

        public double Add(double number1, double number2, double number3)
        {
            return number1 + number2 + number3;
        }

        public decimal Add(decimal number1, decimal number2, decimal number3)
        {
            return number1 + number2 + number3;
        }
    }
}
