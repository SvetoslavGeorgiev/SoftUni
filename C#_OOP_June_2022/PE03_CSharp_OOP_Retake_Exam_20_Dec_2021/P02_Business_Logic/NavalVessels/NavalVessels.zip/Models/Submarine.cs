﻿namespace NavalVessels.Models
{
    using NavalVessels.Models.Contracts;
    using System;
    using System.Collections.Generic;
    using System.Text;

    public class Submarine : Vessel, ISubmarine
    {
        private bool submergeMode = false;
        private const double submarineArmorThicknes = 200.00;
        public Submarine(string name, double mainWeaponCaliber, double speed) 
            : base(name, mainWeaponCaliber, speed, submarineArmorThicknes)
        {
            
        }

        public bool SubmergeMode
        {
            get => submergeMode;
            private set
            {
                submergeMode = value;
            }
        }

        public override void RepairVessel()
        {
            if (ArmorThickness < submarineArmorThicknes)
            {
                base.RepairVessel();
            }
        }


        public void ToggleSubmergeMode()
        {
            if (SubmergeMode == true)
            {
                SubmergeMode = false;
                MainWeaponCaliber -= 40;
                Speed += 4;
            }
            else
            {
                SubmergeMode = true;
                MainWeaponCaliber += 40;
                Speed -= 4;
            }
        }

        public override string ToString()
        {
            var submergeMode = SubmergeMode == true ? " *Submerge mode: ON" : " *Submerge mode: OFF";

            return base.ToString() + Environment.NewLine + submergeMode;
        }
    }
}
