﻿namespace PlanetWars.Models.MilitaryUnits
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    public class StormTroopers : MilitaryUnit
    {
        public StormTroopers() : base(2.5)
        {

        }
    }
}
