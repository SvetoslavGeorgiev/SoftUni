﻿namespace PlanetWars.Models.MilitaryUnits
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    public class SpaceForces : MilitaryUnit
    {
        public SpaceForces() : base(11)
        {

        }
    }
}
