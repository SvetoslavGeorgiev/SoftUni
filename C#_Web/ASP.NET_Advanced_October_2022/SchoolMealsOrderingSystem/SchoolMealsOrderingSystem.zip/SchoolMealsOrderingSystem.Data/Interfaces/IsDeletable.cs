﻿namespace SchoolMealsOrderingSystem.Data.Interfaces
{
    internal interface IsDeletable
    {
        bool IsDeleted { get; set; }

    }
}
