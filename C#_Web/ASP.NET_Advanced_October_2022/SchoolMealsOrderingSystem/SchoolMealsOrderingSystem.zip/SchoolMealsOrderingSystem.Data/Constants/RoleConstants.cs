﻿namespace SchoolMealsOrderingSystem.Data.Constants
{
    public class RoleConstants
    {

        public const string School = "School";
        public const string Parent = "Parent";
        public const string SchoolAndParent = "School, Parent";


    }
}
