namespace SchoolMealsOrderingSystem.Tests
{
    using Core.Services;

    [TestFixture]
    public class TeChildServicesTestssts
    {
        
    }
}